import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite'
import dotenv from 'dotenv';
import { resolve } from 'path';

dotenv.config();

const phasermsg = () => {
    return {
        name: 'phasermsg',
        buildStart() {
            // eslint-disable-next-line no-undef
            process.stdout.write(`Building for production...\n`);
        },
        buildEnd() {
            const line = "---------------------------------------------------------";
            const msg = `❤️❤️❤️ Tell us about your game! - games@phaser.io ❤️❤️❤️`;
            process.stdout.write(`${line}\n${msg}\n${line}\n`);

            process.stdout.write(`✨ Done ✨\n`);
        }
    }
}

export default defineConfig({
    base: './',
    plugins: [
        react(),
        phasermsg(),
        tailwindcss(),
    ],
    resolve: {
        alias: {
            '@': resolve(__dirname, '..')
        }
    },
    define: {
        'process.env.SECRET_KEY': JSON.stringify(process.env.SECRET_KEY),
    },
    logLevel: 'warning',
    build: {
        rollupOptions: {
            output: {
                manualChunks: {
                    phaser: ['phaser']
                }
            }
        },
        minify: 'terser',
        terserOptions: {
            compress: {
                passes: 2
            },
            mangle: true,
            format: {
                comments: false
            }
        }
    }
});
